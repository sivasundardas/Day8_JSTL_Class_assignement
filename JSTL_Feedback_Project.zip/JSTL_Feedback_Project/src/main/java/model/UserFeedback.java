package model;
import java.util.List;

public class UserFeedback {
    private String userName;
    private List<String> facilities;

    public UserFeedback(String userName, List<String> facilities) {
        this.userName = userName;
        this.facilities = facilities;
    }

    public String getUserName() {
        return userName;
    }

    public List<String> getFacilities() {
        return facilities;
    }
}
